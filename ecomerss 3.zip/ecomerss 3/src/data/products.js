export const products = [
    {
        id: 1,
        title: "دفتر ملاحظات فاخر A5",
        category: "school",
        price: 450,
        image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?auto=format&fit=crop&q=80&w=600",
        description: "دفتر ملاحظات عالي الجودة مقاس A5، يحتوي على 200 صفحة مسطرة. غلاف قوي وأنيق مناسب للطلاب والمحترفين. ورق كريمي مريح للعين."
    },
    {
        id: 2,
        title: "طقم أقلام حبر جاف (10 قطع)",
        category: "school",
        price: 300,
        image: "https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&q=80&w=600",
        description: "علبة تحتوي على 10 أقلام حبر جاف أزرق انسيابية الكتابة. سن 0.7 ملم يدوم طويلاً. مثالية للاستخدام اليومي في المدرسة والمكتب."
    },
    {
        id: 3,
        title: "كرسي مكتب مريح",
        category: "office",
        price: 12500,
        image: "https://images.unsplash.com/photo-1580481072958-1826756a85f6?auto=format&fit=crop&q=80&w=600",
        description: "كرسي مكتب طبي قابل للتعديل مع دعم لأسفل الظهر. قاعدة خماسية عجلات لسهولة الحركة. تنجيد قماشي مسامي لراحة تدوم ساعات طويلة."
    },
    {
        id: 4,
        title: "حاسوب محمول (Laptop) عالي الأداء",
        category: "electronics",
        price: 85000,
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=600",
        description: "حاسوب محمول بتصميم عصري وأداء قوي. مناسب للعمل، الدراسة، والمحترفين. يتميز بشاشة عالية الوضوح ومعالج سريع وعمر بطارية طويل."
    },
    {
        id: 5,
        title: "ألوان مائية احترافية",
        category: "art",
        price: 1800,
        image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&q=80&w=600",
        description: "مجموعة ألوان مائية تحتوي على 24 لوناً زاهياً. تركيبة عالية الصبغة وسهلة الدمج. تأتي مع فرشاة احترافية. مناسبة للفنانين والهواة."
    },
    {
        id: 6,
        title: "حامل لوحات رسم خشبي",
        category: "art",
        price: 4500,
        image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=600",
        description: "حامل رسم (Easel) مصنوع من خشب الزان المتين. قابل للتعديل في الارتفاع والزاوية. يستوعب لوحات بأحجام مختلفة حتى ارتفاع 120 سم."
    },
    {
        id: 7,
        title: "حقيبة ظهر مدرسية",
        category: "school",
        price: 2800,
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=600",
        description: "حقيبة ظهر عصرية ومتينة متعددة الجيوب. مقاومة للماء مع أحزمة كتف مبطنة لراحة الظهر. تتسع للكتب واللابتوب ومستلزمات الدراسة."
    },
    {
        id: 8,
        title: "مكتب عمل مودرن",
        category: "office",
        price: 18000,
        image: "https://images.unsplash.com/photo-1518455027359-f3f816b1a238?auto=format&fit=crop&q=80&w=600",
        description: "مكتب بتصميم عصري بسيط (Minimalist). سطح خشبي واسع مع أرجل معدنية قوية. يحتوي على درجين للتخزين. إضافة أنيقة وعملية لمساحة عملك."
    }
];
