// Supabase Configuration
const SUPABASE_URL = 'YOUR_SUPABASE_URL'; // Replace with Project URL
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY'; // Replace with Anon Key

export const supabase = (SUPABASE_URL !== 'YOUR_SUPABASE_URL' && window.supabase)
    ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    : { from: () => ({ insert: () => Promise.resolve({ error: 'Supabase keys missing' }) }) };
