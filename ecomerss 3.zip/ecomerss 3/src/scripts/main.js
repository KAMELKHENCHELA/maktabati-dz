/**
 * MAKTABATI DZ - Main Logic File
 * Handles: Cart, Modals, UI Updates, Netlify Forms & Supabase Integration
 */

import { products } from '../data/products.js';
import communes from '../data/communes.js';
import { supabase } from './supabase-client.js';

// DOM Elements
const productsGrid = document.getElementById('products-grid');
const cartCount = document.getElementById('cart-count');
const cartBtn = document.querySelector('.cart-btn');
const closeCartBtn = document.getElementById('close-cart');
const cartSidebar = document.getElementById('cart-sidebar');
const overlay = document.getElementById('modal-overlay');
const cartItemsContainer = document.getElementById('cart-items');
const cartSubtotalElement = document.getElementById('cart-subtotal');
const cartShippingElement = document.getElementById('cart-shipping');
const cartTotalElement = document.getElementById('cart-total');
const checkoutModal = document.getElementById('checkout-modal');
const closeCheckoutBtn = document.getElementById('close-checkout');
const checkoutForm = document.getElementById('checkout-form');
const checkoutSubtotalDisplay = document.getElementById('checkout-subtotal');
const checkoutShippingDisplay = document.getElementById('checkout-shipping');
const checkoutTotalDisplay = document.getElementById('checkout-total');
const checkoutBtn = document.querySelector('.checkout-btn');
const wilayaSelect = document.getElementById('wilaya');
const communeSelect = document.getElementById('commune');
const userBtn = document.querySelector('.icon-btn.user-btn') || document.querySelector('.fa-user-circle').parentElement;
const authModal = document.getElementById('auth-modal');
const closeAuthBtn = document.getElementById('close-auth');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const authTabBtns = document.querySelectorAll('.auth-tab-btn');
const authSwitchLinks = document.querySelectorAll('.auth-switch a');

// State
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let currentUser = JSON.parse(localStorage.getItem('user')) || null;

// Initialization
function init() {
    renderProducts();
    setupEventListeners();
    updateCartUI();
    updateUserUI();
    setupWilayaListener();
}

// Render Products
function renderProducts() {
    productsGrid.innerHTML = products.map(product => `
        <div class="product-card">
            <div class="product-image" onclick="window.openProductDetails(${product.id})" style="cursor: pointer;">
                <img src="${product.image}" alt="${product.title}">
            </div>
            <div class="product-info">
                <span class="product-category">${getCategoryName(product.category)}</span>
                <h4 class="product-title" onclick="window.openProductDetails(${product.id})" style="cursor: pointer;">${product.title}</h4>
                <div class="product-footer">
                    <span class="price">${formatPrice(product.price)}</span>
                    <button class="add-to-cart-btn" onclick="window.addToCart(${product.id})" aria-label="أضف للسلة">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Helper: Category Names in Arabic
function getCategoryName(category) {
    const names = {
        'school': 'أدوات مدرسية',
        'office': 'أثاث مكتبي',
        'art': 'أدوات فنية',
        'electronics': 'إلكترونيات'
    };
    return names[category] || category;
}

// Helper: Format Price
function formatPrice(price) {
    return `${price.toLocaleString()} د.ج`;
}

// Cart Logic
window.addToCart = (productId) => {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCartUI();
        showToast(`تم إضافة ${product.title} إلى السلة`);
    }
};

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartUI();
}

function updateCartUI() {
    // Update Count
    cartCount.textContent = cart.length;

    // Update Items
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart-msg">السلة فارغة حالياً</p>';
    } else {
        cartItemsContainer.innerHTML = cart.map((item, index) => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.title}">
                <div class="cart-item-details">
                    <h5 class="cart-item-title">${item.title}</h5>
                    <span class="cart-item-price">${formatPrice(item.price)}</span>
                    <button class="cart-item-remove" data-index="${index}">
                        <i class="fas fa-trash"></i> حذف
                    </button>
                </div>
            </div>
        `).join('');

        // Attach event listeners to remove buttons
        document.querySelectorAll('.cart-item-remove').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.closest('button').dataset.index);
                removeFromCart(index);
            });
        });
    }

    // Update Totals
    const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
    const selectedWilaya = wilayaSelect ? wilayaSelect.value : "";
    let shipping = 0;

    if (cart.length > 0) {
        if (selectedWilaya === "40") { // Khenchela
            shipping = 200;
        } else if (selectedWilaya !== "") {
            shipping = 600;
        }
    }

    const total = subtotal + shipping;

    if (cartSubtotalElement) cartSubtotalElement.textContent = formatPrice(subtotal);
    if (cartShippingElement) cartShippingElement.textContent = formatPrice(shipping);
    cartTotalElement.textContent = formatPrice(total);

    // Update Checkout if open
    if (checkoutSubtotalDisplay) checkoutSubtotalDisplay.textContent = formatPrice(subtotal);
    if (checkoutShippingDisplay) checkoutShippingDisplay.textContent = formatPrice(shipping);
    if (checkoutTotalDisplay) checkoutTotalDisplay.textContent = formatPrice(total);

    // Save to LocalStorage
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Sidebar Logic
function openCart() {
    cartSidebar.classList.add('open');
    overlay.classList.add('active');
}

function closeCart() {
    cartSidebar.classList.remove('open');
    overlay.classList.remove('active');
}

// Wilaya & Commune Logic
function setupWilayaListener() {
    if (!wilayaSelect || !communeSelect) return;

    wilayaSelect.addEventListener('change', (e) => {
        const wilayaId = e.target.value;

        // Reset and disable commune select if no wilaya is selected
        if (!wilayaId) {
            communeSelect.innerHTML = '<option value="">اختر البلدية</option>';
            communeSelect.disabled = true;
            return;
        }

        // Filter communes based on selected wilaya
        const filteredCommunes = communes.filter(c => c.wilaya_id === wilayaId);

        // Populate commune select
        communeSelect.innerHTML = '<option value="">اختر البلدية</option>' +
            filteredCommunes.map(c => `<option value="${c.id}">${c.ar_name || c.name}</option>`).join('');

        communeSelect.disabled = false;

        // NEW: Update shipping costs when wilaya changes
        updateCartUI();
    });
}

// Event Listeners
function setupEventListeners() {
    // ... (existing listeners)
    cartBtn.addEventListener('click', openCart);
    closeCartBtn.addEventListener('click', closeCart);
    overlay.addEventListener('click', () => {
        closeCart();
        closeCheckoutModal();
    });

    checkoutBtn.addEventListener('click', openCheckoutModal);
    closeCheckoutBtn.addEventListener('click', closeCheckoutModal);

    checkoutForm.addEventListener('submit', handleCheckoutSubmit);

    // Close product modal
    // Close product modal
    document.getElementById('close-product-modal').addEventListener('click', closeProductModal);

    // Auth interactions
    userBtn.addEventListener('click', () => {
        if (currentUser) {
            handleLogout();
        } else {
            openAuthModal();
        }
    });

    closeAuthBtn.addEventListener('click', closeAuthModal);

    authTabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            switchAuthTab(btn.dataset.tab);
        });
    });

    authSwitchLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            switchAuthTab(link.dataset.switch);
        });
    });

    loginForm.addEventListener('submit', handleLogin);
    registerForm.addEventListener('submit', handleRegister);
}

// User UI Update
function updateUserUI() {
    if (currentUser) {
        userBtn.innerHTML = `
            <div class="user-profile">
                <i class="fas fa-sign-out-alt"></i>
                <span class="user-name">${currentUser.name}</span>
            </div>
        `;
        userBtn.setAttribute('aria-label', 'تسجيل الخروج');
    } else {
        userBtn.innerHTML = `<i class="fas fa-user-circle"></i>`;
        userBtn.setAttribute('aria-label', 'الحساب');
    }
}

// Auth Logic
function openAuthModal() {
    authModal.classList.add('active');
    overlay.classList.add('active');
}

function closeAuthModal() {
    authModal.classList.remove('active');
    overlay.classList.remove('active');
}

function switchAuthTab(tab) {
    authTabBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
    document.querySelector('#login-form').classList.toggle('active', tab === 'login');
    document.querySelector('#register-form').classList.toggle('active', tab === 'register');
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    // Simple simulation
    currentUser = { name: email.split('@')[0], email: email };
    localStorage.setItem('user', JSON.stringify(currentUser));
    updateUserUI();
    closeAuthModal();
    alert(`مرحباً بك مجدداً، ${currentUser.name}!`);
}

function handleRegister(e) {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.textContent;

    const userData = {
        lastname: document.getElementById('reg-lastname').value,
        firstname: document.getElementById('reg-firstname').value,
        email: document.getElementById('reg-email').value,
        phone: document.getElementById('reg-phone').value,
        company: document.getElementById('reg-company').value
    };

    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإنشاء...';
    btn.disabled = true;

    const saveToSupabase = async () => {
        try {
            const { error } = await supabase.from('profiles').insert([userData]);
            if (error) throw error;
            return true;
        } catch (err) {
            console.error('Supabase Error:', err);
            return false;
        }
    };

    saveToSupabase()
        .then((supabaseSuccess) => {
            if (supabaseSuccess) {
                currentUser = { name: userData.firstname, email: userData.email };
                localStorage.setItem('user', JSON.stringify(currentUser));
                updateUserUI();
                closeAuthModal();
                showToast(`تم إنشاء حسابك بنجاح، مرحباً بك ${userData.firstname}!`);
                form.reset();
            } else {
                showToast('حدث خطأ أثناء الإنشاء في Supabase.', 'error');
            }
        })
        .catch(() => {
            showToast('حدث خطأ غير متوقع أثناء الإنشاء.', 'error');
        })
        .finally(() => {
            btn.textContent = originalText;
            btn.disabled = false;
        });
}

function handleLogout() {
    if (confirm('هل تريد تسجيل الخروج؟')) {
        currentUser = null;
        localStorage.removeItem('user');
        updateUserUI();
    }
}

// Product Modal Logic
window.openProductDetails = (id) => {
    const product = products.find(p => p.id === id);
    if (!product) return;

    document.getElementById('modal-img').src = product.image;
    document.getElementById('modal-category').textContent = getCategoryName(product.category);
    document.getElementById('modal-title').textContent = product.title;
    document.getElementById('modal-price').textContent = formatPrice(product.price);
    document.getElementById('modal-description').textContent = product.description;

    // Setup add button
    const addBtn = document.getElementById('modal-add-btn');
    addBtn.onclick = () => {
        window.addToCart(product.id);
        closeProductModal();
    };

    const modal = document.getElementById('product-modal');
    modal.classList.add('active');
    overlay.classList.add('active');
};

function closeProductModal() {
    document.getElementById('product-modal').classList.remove('active');
    overlay.classList.remove('active');
}

// Checkout Logic
function openCheckoutModal() {
    if (cart.length === 0) {
        alert('السلة فارغة!');
        return;
    }
    closeCart();
    checkoutTotalDisplay.textContent = cartTotalElement.textContent;
    checkoutModal.classList.add('active');
    overlay.classList.add('active');
}

function closeCheckoutModal() {
    checkoutModal.classList.remove('active');
    overlay.classList.remove('active');
}

function handleCheckoutSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.textContent;

    const fullname = document.getElementById('fullname').value;
    const phone = document.getElementById('phone').value;
    const wilayaId = document.getElementById('wilaya').value;
    const address = document.getElementById('address').value;

    const subtotal = cart.reduce((sum, item) => sum + item.price, 0);
    const selectedWilaya = wilayaSelect.value;
    const shipping = selectedWilaya === "40" ? 200 : (selectedWilaya !== "" ? 600 : 0);
    const total = subtotal + shipping;

    const orderDetails = {
        customer_name: fullname,
        phone: phone,
        wilaya: wilayaId,
        address: address,
        items: cart.map(item => ({ title: item.title, price: item.price })),
        subtotal: subtotal,
        shipping_cost: shipping,
        total_price: total
    };

    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري إرسال الطلب...';
    btn.disabled = true;

    // Save to Supabase
    const saveToSupabase = async () => {
        try {
            const { data, error } = await supabase
                .from('orders')
                .insert([orderDetails]);

            if (error) throw error;
            return true;
        } catch (err) {
            console.error('Supabase Error:', err);
            return false;
        }
    };

    saveToSupabase().then((supabaseSuccess) => {
        showToast(supabaseSuccess ? 'تم استلام طلبك بنجاح!' : 'تم إرسال الطلب عبر واتساب.');

        // WhatsApp Redirection
        const waBody = `طلب جديد من: ${orderDetails.customer_name}\nالهاتف: ${orderDetails.phone}\nالعنوان: ${orderDetails.address}\nالولاية: ${orderDetails.wilaya}\n\nالمنتجات:\n${cart.map(item => `- ${item.title}`).join('\n')}\n\nالمجموع الكلي: ${orderDetails.total_price} د.ج`;
        const waUrl = `https://wa.me/213656813384?text=${encodeURIComponent(waBody)}`;

        setTimeout(() => {
            window.open(waUrl, '_blank');
        }, 1000);

        cart = [];
        updateCartUI();
        closeCheckoutModal();
        form.reset();
        btn.textContent = originalText;
        btn.disabled = false;
        localStorage.removeItem('cart');
    })
        .catch(() => {
            showToast('حدث خطأ أثناء إرسال الطلب.', 'error');
            btn.textContent = originalText;
            btn.disabled = false;
        });
}

// Toast Notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 100);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// Start
init();
